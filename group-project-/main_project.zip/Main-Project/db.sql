Use db;
DROP TABLE IF EXISTS BRANDNEW;
DROP TABLE IF EXISTS USED;
DROP TABLE IF EXISTS Users; 

CREATE TABLE Users (
USERID 	INT NOT NULL,
RNAME 	VARCHAR(20),
UNAME	VARCHAR(20),
PASS    VARCHAR(12),
PNUM    INT NOT NULL,
ADDR 	VARCHAR(25),
EMAIL	VARCHAR(25),
 CONSTRAINT Users_PRIMARY_KEY PRIMARY KEY (USERID));


INSERT INTO Users VALUES (20,'Nicole Burroughs','NicoleB1234','root',0851035828,
'6 new oak Estate, Carlow', 'NikkiNova123@gmail.com');

INSERT INTO Users VALUES (25, 'Mark Carey', 'MCarey2017', 'Password', 0879688225, '6A Killarney Court'
, 'MarkCarey2017@gmail.com');

INSERT INTO Users VALUES (50, 'John Byrne', 'JohnB9583', 'dublin1993', 087124892,
 '26 Parnell Street, Dublin','John09Byrne@gmail.com');
 
CREATE TABLE USED(
USERID INT NOT NULL,
BNAME 	VARCHAR(40),
AUTHOR	VARCHAR(40),
BPRICE	DOUBLE NOT NULL,
IMAGE 	VARCHAR(20),
CONDIT	VARCHAR(20),
PRODUCTID	INT NOT NULL,
 CONSTRAINT USED_PRIMARY_KEY PRIMARY KEY (PRODUCTID),
FOREIGN KEY (USERID) REFERENCES Users(USERID));

INSERT INTO USED VALUES (20, 'The lord of the Rings','jrr tolkien', 10.00, 'images/lord.jpg', 'USED', 1);
INSERT INTO USED VALUES (20, 'Harry Potter and The Cursed Child', 'JK Rowling', 15, 'images/cursed.jpg', 'USED', 2);
INSERT INTO USED VALUES (20, 'The Shining','Stephen King', 12.00, 'images/shining.jpg', 'USED', 3);
INSERT INTO USED VALUES (25, 'Halo: The Fall of Reach','Eric Nylund', 8.00, 'images/halo.jpg', 'USED', 4);
INSERT INTO USED VALUES (25, 'The Green Mile','Stephen King', 11.00, 'images/green.jpg', 'USED', 5);
INSERT INTO USED VALUES (25, 'Harry Potter and The Deathly Dallows', 'JK Rowling', 5.00, 'images/deathly.png', 'USED', 6);
INSERT INTO USED VALUES (50, 'The Mist','Stephen King', 14.00, 'images/mist.jpg', 'USED', 7);
INSERT INTO USED VALUES (50, 'Harry Potter and the Chamber of Secrets', 'JK Rowling', 10, 'images/chamber.jpg', 'USED', 8);
INSERT INTO USED VALUES (50, 'DRACULA','Bram Stoker', 14, 'images/drac.jpg', 'USED', 9);
INSERT INTO USED VALUES (50, 'Harry Potter and The Goblet of Fire', 'JK Rowling', 17, 'images/goblet.jpg', 'USED', 10);



CREATE TABLE BRANDNEW(
USERID INT NOT NULL,
BNAME 	VARCHAR(40),
AUTHOR	VARCHAR(40),
BPRICE	DOUBLE NOT NULL,
IMAGE 	VARCHAR(20),
CONDIT	VARCHAR(20),
PRODUCTID	INT NOT NULL,
FOREIGN KEY (USERID) REFERENCES USERS(USERID));

INSERT INTO BRANDNEW VALUES (50, 'The lord of the Rings','jrr tolkien', 20.00, 'images/lord.jpg', 'NEW', 11);
INSERT INTO BRANDNEW VALUES (50, 'Harry Potter and The Cursed Child', 'JK Rowling', 20.00, 'images/cursed.png', 'NEW', 12);
INSERT INTO BRANDNEW VALUES (50, 'The Shining','Stephen King', 18.00, 'images/shining.jpg', 'NEW', 13);
INSERT INTO BRANDNEW VALUES (20, 'Halo: The Fall of Reach','Eric Nylund', 12.00, 'images/halo.jpg', 'NEW', 14);
INSERT INTO BRANDNEW VALUES (20, 'The Green Mile','Stephen King', 25.00, 'images/green.jpg', 'NEW', 15);
INSERT INTO BRANDNEW VALUES (20, 'Harry Potter and The Deathly Dallows', 'JK Rowling', 10.00, 'images/deathly.png', 'NEW', 16);
INSERT INTO BRANDNEW VALUES (25, 'The Mist','Stephen King', 24.00, 'images/mist.jpg', 'NEW', 17);
INSERT INTO BRANDNEW VALUES (25, 'Harry Potter and the Chamber of Secrets', 'JK Rowling', 20.00, 'images/chamber.jpg', 'NEW', 18);
INSERT INTO BRANDNEW VALUES (25, 'DRACULA','Bram Stoker', 30.00, 'images/drac.png', 'NEW', 19);
INSERT INTO BRANDNEW VALUES (25, 'Harry Potter and The Goblet of Fire', 'JK Rowling', 27.00, 'images/goblet.jpg', 'NEW', 20);



Select *
from users;

SELECT *
FROM USED;

SELECT *
FROM brandnew