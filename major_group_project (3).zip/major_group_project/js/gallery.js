

//script for 1st image
var smallImg1 = new Image();

smallImg1.src = "images/golf-swing-gallery.jpg";

var bigImg1 = new Image();

bigImg1.src = "images/golf-swing-gallery-2.jpg";

//script for 2nd image
var smallImg2 = new Image();

smallImg2.src = "images/golf-field-gallery.jpg";

var bigImg2 = new Image();

bigImg2.src = "images/golf-field-gallery-2.jpg";

//script for 3rd image
var smallImg3 = new Image();

smallImg3.src = "images/golf-field2-gallery.jpg";

var bigImg3 = new Image();

bigImg3.src = "images/golf-field2-gallery-2.jpg";

//script for 4th image
var smallImg4 = new Image();

smallImg4.src = "images/clubhouse-house.jpg";

var bigImg4 = new Image();

bigImg4.src = "images/clubhouse-house-2.jpg";