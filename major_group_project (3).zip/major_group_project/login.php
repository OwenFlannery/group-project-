<?php

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset ="utf-8">

    <link rel="stylesheet" type="text/css" href="css/page_layout.css">

    <title>login page</title>
</head>
<body>
<header>

</header>
    <!--***************************************search bar and nav bar ******************************-->
<div class="search_nav">
    <form method="post" action="search.php?go" id="search_form">
        <input type="text" name="search_bar" placeholder="search book titles">
        <input type="submit" name="submit" value="search">
    </form>
</div>

<nav>
    <ul class="nav_ul">
        <li class="nav_li"><a href="index.php" title="Home">Home</a></li>
        <li class="nav_li"><a href="edu.php" title="Educational Books ">Educational Books</a></li>
        <li class="nav_li"><a href="rec.php" title="Recreational Books ">Recreational Books</a></li>
        <li class="nav_li"><a href="trade.php"  title="Tradable Books ">Tradable Books</a></li>
        <li class="nav_li"><a class="current_page" href="login.php" title="login/new user ">login/new user</a></li>
        <li class="nav_li"><a href="contact_us.php" title="Contact Us ">Contact Us</a></li>
    </ul>
</nav>
<div class="login">
    <form method="post" action="index.php" id="new_form">
        <input type="text" name="* username" placeholder="enter username here">
        <br>
        <input type="password" name="* password" placeholder="enter password here">
        <br>
        <input type="password" name="* confirm password" placeholder="confirm password here">
        <br>
        <input type="text" name="* address" placeholder="enter your address here">
        <br>
        <input type="text" name="* contact number" placeholder="enter phone number here">
        <br>
        <input type="text" name="skype contact information" placeholder="non mandatory">
        <br>
        <input type="submit" name="submit" value="create account">
    </form>
</div>

<footer>

</footer>
</body>
</html>












