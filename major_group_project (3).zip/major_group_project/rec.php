<?php
/**
 * Created by PhpStorm.
 * User: owen
 * Date: 05/12/2016
 * Time: 20:22
 */
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset ="utf-8">
    <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
    <style>
        @import "css/page_layout.css";
    </style>

    <script src="js/shopping_cart.js" language="JavaScript"> </script>

    <title>recreational books</title>
</head>

<body>
<header>
    <!--***************************************search bar and nav bar ******************************-->
    <form method="post" action="search.php?go" id="search_form">
        <input type="text" name="search_bar" placeholder="search book titles">
        <input type="submit" name="submit" value="search">
    </form>
    <!--***************************nav bar***********************-->
    <nav>
        <ul class="nav_ul">
            <li class="nav_li"><a href="index.php" data-toggle="dropdown" title="Home">Home</a></li>
            <li class="nav_li"><a class="current_page" href="edu.php" data-toggle="dropdown" title="Educational Books">Educational Books</a></li>
            <li class="nav_li"><a href="rec.php" data-toggle="dropdown" title="Recreational Books">Recreational Books</a></li>
            <li class="nav_li"><a href="trade.php" data-toggle="dropdown" title="Tradable Books">Tradable Books</a></li>
            <li class="nav_li"><a href="contact.html" data-toggle="dropdown" title="Contact Us">Contact Us</a></li>
        </ul>
    </nav>
</header>





<footer>

</footer>

</body>
</html>